console.log('Loading function');
var aws = require('aws-sdk');
var ses = new aws.SES({
   region: 'us-east-1'
});
var ddb = new aws.DynamoDB({params: {TableName: 'astack-csye6225-dynamodb-table'}});
//var data = "asdf";
//var crypto = require('crypto');
//crypto.createHash('md5').update(data).digest("hex");

exports.handler = function(event, context, callback) {
    console.log("Incoming: ", event);
    var useremail = event.Records[0].Sns.Message;
    console.log('Hello, Message received from SNS:', useremail);
    var eParams = {
        Destination: {
            ToAddresses: [useremail]
        },
        Message: {
            Body: {
                Text: {
                    Data: "Click Here:"
                }
            },
            Subject: {
                Data: "WebApp: Your reset password link is here!"
            }
        },
        Source: "zeus@csye6225-spring2018-aggarwalash.me"
    };

    console.log('===SENDING EMAIL===');
    var currDate=new Date();
    console.log("curr:"+currDate);
    var ttl=Math.floor(currDate.setMinutes(currDate.getMinutes() + 20)/1000);
    console.log("ttl:"+ttl);
    var itemParams ={
      Item:{
        "token":{S:useremail},
        "ttl":{N:ttl}
      }
    };
    ddb.putItem(itemParams, function() {
    var email = ses.sendEmail(eParams, function(err, data){
        if(err) console.log(err);
        else {
            console.log("===EMAIL SENT===");
            console.log(data);


            console.log("EMAIL CODE END");
            console.log('EMAIL: ', email);
            context.succeed(event);

        }
    });
    });
//    callback(null, "Success");
};
